export const API_BASE_URL =
  process.env.REACT_APP_API_BASE_URL || "https://unspattered-cherrie-calculational.ngrok-free.dev";

export const API_PATHS = {
  login: "/api/accounts/login/",
  refresh: "/api/accounts/token/refresh/",
  me: "/api/accounts/me/",
  signup: "/api/accounts/signup/",
  userPassword: (id) => `/api/accounts/users/${id}/password/`,
  userDelete: (id) => `/api/accounts/users/${id}/delete/`,
};
