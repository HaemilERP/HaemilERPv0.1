export default function Purchase() {
  return (
    <div className="page-card">
      <h2 style={{ margin: 0 }}>발주</h2>
      <div style={{ marginTop: "var(--sp-12)", color: "#64748b", fontSize: "var(--fs-14)" }}>
        발주 기능은 여기에서 확장할 수 있습니다. (현재는 탭/라우팅만 추가)
      </div>
    </div>
  );
}
