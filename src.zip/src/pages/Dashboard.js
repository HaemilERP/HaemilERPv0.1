export default function Dashboard() {
  return (
    <div className="page-card">
      <h2>대시보드</h2>
      <p style={{ color: "#64748b" }}>개요 화면입니다.</p>
    </div>
  );
}
