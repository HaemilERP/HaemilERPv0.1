export default function Inventory() {
  return (
    <div className="page-card">
      <h2>재고관리</h2>
      <p style={{ color: "#64748b" }}>좌측 메뉴에서 기능을 선택하세요.</p>
    </div>
  );
}
