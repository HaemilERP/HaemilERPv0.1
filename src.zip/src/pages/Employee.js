export default function Employee() {
  return (
    <div className="page-card">
      <h2>인사관리</h2>
      <p style={{ color: "#64748b" }}>좌측 메뉴에서 기능을 선택하세요.</p>
    </div>
  );
}
