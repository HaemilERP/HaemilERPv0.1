import { createContext, useContext, useMemo, useState, useEffect } from "react";
import { getInitialAuthState, loginRequest, logoutRequest } from "../services/authApi";
import { api } from "../services/apiClient";
import { API_PATHS } from "../config/api";

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const initial = useMemo(() => getInitialAuthState(), []);
  const [isAuthenticated, setIsAuthenticated] = useState(initial.isAuthenticated);
  const [user, setUser] = useState(initial.user);
  const [authLoading, setAuthLoading] = useState(false);

  // ✅ 토큰이 있으면 /me로 role 확정 (새로고침/직접 URL 진입에도 ADMIN 유지)
  useEffect(() => {
    const boot = async () => {
      if (!initial.isAuthenticated) return;

      try {
        const meRes = await api.get(API_PATHS.me);
        const me = meRes.data;
        setUser({ ...me, isAdmin: me?.role === "ADMIN" });
        setIsAuthenticated(true);
      } catch (e) {
        // 토큰이 유효하지 않으면 로그아웃 처리
        logoutRequest();
        setUser(null);
        setIsAuthenticated(false);
      }
    };

    boot();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const login = async ({ username, password }) => {
    setAuthLoading(true);
    try {
      const { user: u } = await loginRequest({ username, password });
      setUser(u);
      setIsAuthenticated(true);
      return { ok: true };
    } catch (e) {
      setUser(null);
      setIsAuthenticated(false);
      return {
        ok: false,
        message: e?.response?.data?.detail || e?.response?.data?.message || e?.message || "Login failed",
      };
    } finally {
      setAuthLoading(false);
    }
  };

  const logout = () => {
    logoutRequest();
    setUser(null);
    setIsAuthenticated(false);
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, user, authLoading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
